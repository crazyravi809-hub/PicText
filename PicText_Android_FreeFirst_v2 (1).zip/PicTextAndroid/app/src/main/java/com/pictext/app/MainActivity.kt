package com.pictext.app

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.io.InputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PicTextApp() }
    }
}

@Composable
fun PicTextApp() {
    val context = LocalContext.current
    var sourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var overlayText by remember { mutableStateOf("Your text") }
    var textColor by remember { mutableStateOf(Color.White) }
    var onlineMode by remember { mutableStateOf(true) }
    var showOnlineInfo by remember { mutableStateOf(false) }
    var isRecognizing by remember { mutableStateOf(false) }
    var recognizedText by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val stream: InputStream? = context.contentResolver.openInputStream(uri)
                sourceBitmap = BitmapFactory.decodeStream(stream)
                stream?.close()
            } catch (_: Exception) {
                Toast.makeText(context, "Couldn't open this image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFFB69CFF),
        secondary = Color(0xFF8B6CFF),
        background = Color(0xFF0B0B12),
        surface = Color(0xFF171722)
    )) {
        Column(
            Modifier.fillMaxSize().background(Color(0xFF0B0B12))
                .verticalScroll(rememberScrollState()).padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Pic", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("Text", color = Color(0xFFB69CFF), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.weight(1f))
                Text("AI IMAGE EDITOR", color = Color(0xFFAAA6B8), fontSize = 10.sp, letterSpacing = 1.5.sp)
            }
            Spacer(Modifier.height(6.dp))
            Text("Edit text. Keep the picture.", color = Color(0xFFBDB8CA), fontSize = 14.sp)
            Spacer(Modifier.height(22.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !onlineMode, onClick = { onlineMode = false },
                    label = { Text("Offline") }, leadingIcon = { Icon(Icons.Default.Image, null) })
                FilterChip(selected = onlineMode, onClick = { onlineMode = true },
                    label = { Text("Online AI") }, leadingIcon = { Icon(Icons.Default.Cloud, null) })
            }
            Spacer(Modifier.height(16.dp))

            Box(
                Modifier.fillMaxWidth().height(300.dp)
                    .background(Color(0xFF1B1A26), RoundedCornerShape(20.dp))
                    .border(1.dp, Color(0xFF393348), RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (sourceBitmap == null) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Image, null, tint = Color(0xFFB69CFF), modifier = Modifier.size(48.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("Choose an image to start", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("JPG, PNG and other gallery images", color = Color(0xFFAAA6B8), fontSize = 12.sp)
                    }
                } else {
                    Image(sourceBitmap!!.asImageBitmap(), null, modifier = Modifier.fillMaxWidth().height(300.dp))
                    Text(overlayText, color = textColor, fontSize = 25.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.Center))
                }
            }
            Spacer(Modifier.height(14.dp))

            Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8060E8))) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(8.dp))
                Text(if (sourceBitmap == null) "Choose Image" else "Change Image")
            }

            Spacer(Modifier.height(18.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF171722)),
                modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TextFields, null, tint = Color(0xFFB69CFF))
                        Spacer(Modifier.width(8.dp))
                        Text("Text overlay", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = overlayText, onValueChange = { overlayText = it },
                        modifier = Modifier.fillMaxWidth(), label = { Text("Enter text") },
                        singleLine = false)
                    Spacer(Modifier.height(10.dp))
                    Text("Text colour", color = Color(0xFFBDB8CA), fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 8.dp)) {
                        listOf(Color.White, Color.Black, Color(0xFFFFD54F), Color(0xFFFF6B6B), Color(0xFF8DE1FF)).forEach { c ->
                            Box(Modifier.size(32.dp).background(c, RoundedCornerShape(50))
                                .border(if (textColor == c) 3.dp else 1.dp, Color(0xFFB69CFF), RoundedCornerShape(50))
                                .clickable { textColor = c })
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            OutlinedButton(
                enabled = sourceBitmap != null && !isRecognizing,
                onClick = {
                    if (onlineMode) {
                        showOnlineInfo = true
                    } else {
                        val bitmap = sourceBitmap
                        if (bitmap == null) {
                            Toast.makeText(context, "Choose an image first", Toast.LENGTH_SHORT).show()
                        } else {
                            isRecognizing = true
                            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                            val input = InputImage.fromBitmap(bitmap, 0)
                            recognizer.process(input)
                                .addOnSuccessListener { result ->
                                    recognizedText = result.text
                                    if (result.text.isNotBlank()) {
                                        overlayText = result.text.lines().firstOrNull().orEmpty()
                                        Toast.makeText(context, "Text detected. First line added to editor.", Toast.LENGTH_LONG).show()
                                    } else {
                                        Toast.makeText(context, "No supported text found. Latin script OCR is supported in this offline build.", Toast.LENGTH_LONG).show()
                                    }
                                }
                                .addOnFailureListener {
                                    Toast.makeText(context, "Text recognition failed. Try a clearer image.", Toast.LENGTH_LONG).show()
                                }
                                .addOnCompleteListener {
                                    isRecognizing = false
                                    recognizer.close()
                                }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(if (onlineMode) Icons.Default.Cloud else Icons.Default.TextFields, null)
                Spacer(Modifier.width(8.dp))
                Text(
                    when {
                        isRecognizing -> "Recognizing text..."
                        onlineMode -> "Online AI text detection (setup needed)"
                        else -> "Detect text offline (Latin script)"
                    }
                )
            }
            if (recognizedText.isNotBlank()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF171722)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Detected text", color = Color(0xFFB69CFF), fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(recognizedText, color = Color.White, fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        TextButton(onClick = { overlayText = recognizedText }) {
                            Text("Use all detected text")
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    val original = sourceBitmap
                    if (original == null) {
                        Toast.makeText(context, "Choose an image first", Toast.LENGTH_SHORT).show()
                    } else {
                        try {
                            val output = original.copy(Bitmap.Config.ARGB_8888, true)
                            val canvas = Canvas(output)
                            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                color = android.graphics.Color.argb(
                                    (textColor.alpha * 255).toInt(),
                                    (textColor.red * 255).toInt(),
                                    (textColor.green * 255).toInt(),
                                    (textColor.blue * 255).toInt()
                                )
                                textSize = output.width * 0.07f
                                typeface = Typeface.create("sans-serif", Typeface.BOLD)
                                textAlign = Paint.Align.CENTER
                                setShadowLayer(5f, 2f, 2f, android.graphics.Color.BLACK)
                            }
                            canvas.drawText(overlayText, output.width / 2f, output.height / 2f, paint)
                            val values = ContentValues().apply {
                                put(MediaStore.Images.Media.DISPLAY_NAME, "PicText_${System.currentTimeMillis()}.png")
                                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PicText")
                            }
                            val outUri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                            if (outUri != null) {
                                context.contentResolver.openOutputStream(outUri)?.use { output.compress(Bitmap.CompressFormat.PNG, 100, it) }
                                Toast.makeText(context, "Saved to Pictures/PicText", Toast.LENGTH_LONG).show()
                            } else Toast.makeText(context, "Couldn't save image", Toast.LENGTH_SHORT).show()
                        } catch (_: Exception) {
                            Toast.makeText(context, "Export failed", Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8060E8))
            ) {
                Icon(Icons.Default.Download, null)
                Spacer(Modifier.width(8.dp))
                Text("Export HD Image")
            }
            Spacer(Modifier.height(22.dp))
            Text("PicText • Version 1.0 MVP", color = Color(0xFF777386), fontSize = 11.sp)
        }
    }

    if (showOnlineInfo) {
        AlertDialog(
            onDismissRequest = { showOnlineInfo = false },
            title = { Text("Online AI features") },
            text = { Text("Online AI requires a secure backend and an API key. This build includes offline Latin-script OCR using ML Kit. Tamil OCR, font matching, and AI background reconstruction need an online OCR/inpainting service and backend integration before release.") },
            confirmButton = { TextButton(onClick = { showOnlineInfo = false }) { Text("OK") } }
        )
    }
}
