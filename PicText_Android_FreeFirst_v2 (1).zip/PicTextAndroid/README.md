# PicText Android starter – free-first build

Native Android Studio project for the PicText MVP.

## Included in this source build
- Native Android app shell with PicText branding
- Gallery image picker
- Offline text overlay editor
- Text colour choices
- On-device OCR for supported Latin-script text using bundled ML Kit
- Editable OCR result and PNG export to `Pictures/PicText`
- Online/offline mode selector

## Important feature limits
- ML Kit's bundled default text recognizer is for Latin script. It does not provide Tamil-script OCR in this configuration. Tamil OCR needs a separate compatible OCR service/model.
- The online AI button is a placeholder until a secure backend is connected.
- Font identification/matching and seamless removal/reconstruction of existing text are not delivered by OCR alone. They need additional models/services and image-processing work.
- Do not put Gemini/OpenAI API keys directly in the Android APK. Use a backend proxy with rate limits and secret storage.

## Build an APK
1. Install Android Studio (latest stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync and dependency downloads.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.pictext.app`
Minimum Android: Android 8.0 (API 26)
Version: 1.0.0

## Free-first architecture
- Offline: bundled ML Kit Latin OCR + local image editing/export.
- Online: add a backend endpoint for Gemini/other AI OCR and inpainting. Free-tier limits depend on the provider and can change.

## Optional cloud APK build (GitHub Actions)
This project includes `.github/workflows/android-apk.yml`.
1. Create a new GitHub repository and upload the contents of this project.
2. Open the repository's **Actions** tab.
3. Run **Build PicText APK** (or push to `main`).
4. When the workflow completes, open its run and download the `PicText-debug-apk` artifact.
5. Extract the ZIP and install `app-debug.apk` on your Android phone. You may need to allow installation from that source.

This produces a debug APK for testing, not a signed Play Store release.
